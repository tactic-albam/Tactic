package com.tacticlogistics.integrador.db.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tacticlogistics.integrador.db.handlers.DbHandler;
import com.tacticlogistics.integrador.db.handlers.DbRequest;
import com.tacticlogistics.integrador.model.etl.Archivo;
import com.tacticlogistics.integrador.model.etl.ArchivoRepository;
import com.tacticlogistics.integrador.model.etl.EstadoEtlType;
import com.tacticlogistics.integrador.model.etl.TipoArchivoRepository;

import lombok.val;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DbIntegrationService {
	@Autowired
	private List<DbHandler> handlers;

	private DbHandler rootChain = null;

	@Autowired
	private ArchivoRepository archivoRepository;

	@Autowired
	private TipoArchivoRepository tipoArchivoRepository;

	public void run() {
		DbHandler handler = getRootResponsabilityChain();

		val archivos = archivoRepository.findByEstadoArchivo(EstadoEtlType.VALIDADO);
		for (Archivo archivo : archivos) {
			val tipoArchivo = tipoArchivoRepository.findOne(archivo.getIdTipoArchivo());

			DbRequest request = new DbRequest();
			request.setTipoArchivo(tipoArchivo);
			request.setArchivo(archivo);
			handler.receiveRequest(request);
		}
	}
	
	private DbHandler getRootResponsabilityChain() {
		if (rootChain == null) {
			for (int i = 0; i < handlers.size(); i++) {
				if (rootChain == null) {
					rootChain = this.handlers.get(i);
				} else {
					rootChain.setNextHandler(this.handlers.get(i));
				}
			}
		}
		return rootChain;
	}
}