package com.tacticlogistics.integrador.db.clientes.tactic.wms.pf;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.tacticlogistics.integrador.db.clientes.tactic.wms.pf.productosmedidas.jaxb.CTRLSEG;
import com.tacticlogistics.integrador.db.clientes.tactic.wms.pf.productosmedidas.jaxb.ObjectFactory;
import com.tacticlogistics.integrador.db.clientes.tactic.wms.pf.productosmedidas.jaxb.PARTFOOTDTLSEG;
import com.tacticlogistics.integrador.db.clientes.tactic.wms.pf.productosmedidas.jaxb.PARTFOOTINBIFD;
import com.tacticlogistics.integrador.db.clientes.tactic.wms.pf.productosmedidas.jaxb.PARTFOOTSEG;
import com.tacticlogistics.integrador.db.handlers.DbHandler;
import com.tacticlogistics.integrador.db.handlers.DbRequest;
import com.tacticlogistics.integrador.model.clientes.tactic.wms.pf.ProntoFormProductoMedida;
import com.tacticlogistics.integrador.model.clientes.tactic.wms.pf.ProntoFormProductoMedidaRepository;
import com.tacticlogistics.integrador.model.etl.Archivo;
import com.tacticlogistics.integrador.model.etl.ArchivoRepository;
import com.tacticlogistics.integrador.model.etl.EstadoEtlType;

import lombok.val;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DbProntoFormProductoMedidaHandler extends DbHandler {
	private static final String FORMATO_DECIMAL = "0.#";

	private static final char SEPARADOR_GRUPO = ',';

	private static final char SEPARADOR_DECIMAL = '.';

	private static final String EXTENSION_TRG = ".TRG";

	private static final String EXTENSION_XML = ".XML";

	private static final String SEARCH_CHARS = "<>:'\"/\\|?* ";

	private static final String REPLACE_CHARS = StringUtils.repeat("_", SEARCH_CHARS.length());

	private static final String XML_ENCODING = "ISO-8859-15";

	private static final String CODIGO_TIPO_ARCHIVO = "WMS_PF_PRODUCTOS_MEDIDAS";

	private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmmss");

	@Value("${wms.directorios.entradas}")
	private String directorioWms;

	@Autowired
	private ArchivoRepository archivoRepository;

	@Autowired
	private ProntoFormProductoMedidaRepository repository;

	@Override
	protected boolean canHandleRequest(DbRequest request) {
		if (CODIGO_TIPO_ARCHIVO.equals(request.getTipoArchivo().getCodigo())) {
			return true;
		}
		return false;
	}

	@Override
	@Transactional
	protected void handleRequest(DbRequest request) {
		ObjectFactory factory = null;
		Marshaller marshaller = null;
		boolean procesado = false;
		boolean errorProcesamiento = false;

		val directorio = Paths.get(directorioWms);
		val registros = repository.findByIdArchivo(request.getArchivo().getId());
		String archivoNombre = FilenameUtils.removeExtension(request.getArchivo().getNombre());
		LocalDateTime fechaActualizacion = LocalDateTime.now();
		String fecha = fechaActualizacion.format(formatter);
		Charset defaultCharset = Charset.defaultCharset();

		try {
			factory = new ObjectFactory();
			JAXBContext jaxbContext = JAXBContext.newInstance(PARTFOOTINBIFD.class.getPackage().getName());

			marshaller = jaxbContext.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.setProperty(Marshaller.JAXB_ENCODING, XML_ENCODING);
		} catch (JAXBException e) {
			log.error("", e);
			return;
		}

		for (val registro : registros) {
			String productoCodigo = getProductoCodigo(registro);
			String filename = String.format("%1s-%2s-%3s", fecha, archivoNombre, productoCodigo);

			Path filenameXML = directorio.resolve(filename + EXTENSION_XML);
			Path filenameTRG = directorio.resolve(filename + EXTENSION_TRG);

			try {
				PARTFOOTINBIFD partfootinbifd = buildXMLPartFoot(registro, factory);
				marshaller.marshal(partfootinbifd, filenameXML.toFile());

				FileUtils.writeStringToFile(filenameTRG.toFile(), "", defaultCharset);
				registro.setEstadoRegistro(EstadoEtlType.PROCESADO);
				procesado = true;
			} catch (JAXBException | IOException e) {
				registro.setEstadoRegistro(EstadoEtlType.ERROR_PROCESAMIENTO);
				errorProcesamiento = true;
			}

			registro.setFechaActualizacion(fechaActualizacion);
			registro.setUsuarioActualizacion(SystemUtils.USER_NAME);
			repository.save(registro);
		}

		Archivo archivo = archivoRepository.findOne(request.getArchivo().getId());
		if (procesado) {
			if (!errorProcesamiento) {
				archivo.setEstadoArchivo(EstadoEtlType.PROCESADO);
			} else {
				archivo.setEstadoArchivo(EstadoEtlType.PROCESADO_CON_NOVEDADES);
			}
		} else {
			archivo.setEstadoArchivo(EstadoEtlType.ERROR_PROCESAMIENTO);
		}

		archivo.setFechaProcesamiento(fechaActualizacion);
		archivo.setFechaActualizacion(fechaActualizacion);
		archivo.setUsuarioActualizacion(SystemUtils.USER_NAME);
		archivoRepository.save(archivo);
	}

	private String getProductoCodigo(
			final com.tacticlogistics.integrador.model.clientes.tactic.wms.pf.ProntoFormProductoMedida registro) {
		String productoCodigo;
		productoCodigo = registro.getProductoCodigo();
		if (StringUtils.containsAny(productoCodigo, SEARCH_CHARS)) {
			productoCodigo = StringUtils.replaceChars(productoCodigo, SEARCH_CHARS, REPLACE_CHARS);
		}
		return productoCodigo;
	}

	private PARTFOOTINBIFD buildXMLPartFoot(final ProntoFormProductoMedida registro, ObjectFactory factory) {
		PARTFOOTINBIFD partfootinbifd = factory.createPARTFOOTINBIFD();
		CTRLSEG ctrlseg;
		;
		PARTFOOTSEG partfootseg;
		PARTFOOTDTLSEG partfootdtlseg;

		ctrlseg = buildXMLCtrlSeg(registro, factory);
		partfootseg = buildXMLPartFootSeg(registro, factory);

		partfootdtlseg = buildXMLPartFootDtlNivel0(registro, factory);
		if (partfootdtlseg != null) {
			partfootseg.getPARTFOOTDTLSEG().add(partfootdtlseg);
		}

		partfootdtlseg = buildXMLPartFootDtlNivel1(registro, factory);
		if (partfootdtlseg != null) {
			partfootseg.getPARTFOOTDTLSEG().add(partfootdtlseg);
		}

		partfootdtlseg = buildXMLPartFootDtlNivel2(registro, factory);
		if (partfootdtlseg != null) {
			partfootseg.getPARTFOOTDTLSEG().add(partfootdtlseg);
		}

		ctrlseg.setPARTFOOTSEG(partfootseg);
		partfootinbifd.setCTRLSEG(ctrlseg);

		return partfootinbifd;
	}

	private CTRLSEG buildXMLCtrlSeg(final ProntoFormProductoMedida registro, ObjectFactory factory) {
		CTRLSEG ctrlseg;

		ctrlseg = factory.createCTRLSEG();
		ctrlseg.setTRNNAM("PARTFOOT_TRAN");
		ctrlseg.setTRNVER("2015.1");
		ctrlseg.setWHSEID(registro.getBodegaCodigo());

		return ctrlseg;
	}

	private PARTFOOTSEG buildXMLPartFootSeg(final ProntoFormProductoMedida registro, ObjectFactory factory) {
		PARTFOOTSEG partfootseg;

		partfootseg = factory.createPARTFOOTSEG();
		partfootseg.setSEGNAM("PARTFOOT");
		partfootseg.setTRNTYP("A");
		partfootseg.setPRTNUM(registro.getProductoCodigo());
		partfootseg.setFTPCOD(registro.getHuellaCodigo());
		partfootseg.setPRTCLIENTID(registro.getClienteCodigo());
		partfootseg.setLNGDSC(registro.getProductoNombre());
		partfootseg.setLOCALEID("ES-ES");
		partfootseg.setCASLVL(String.valueOf(registro.getCaseLevel()));
		partfootseg.setPALSTCKHGT("0");
		partfootseg.setDEFFTPFLG("1");

		return partfootseg;
	}

	private PARTFOOTDTLSEG buildXMLPartFootDtlNivel0(final ProntoFormProductoMedida registro, ObjectFactory factory) {
		PARTFOOTDTLSEG partfootdtlseg;
		// @formatter:off
		partfootdtlseg = buildXMLPartFootDtl(
				registro.getUnidadCodigo1(), 
				registro.getFactorConversion1(),
				registro.getLargo1(),
				registro.getAncho1(),
				registro.getAlto1(),
				registro.getPeso1(),
				factory);
		// @formatter:on

		fillValoresNivel0(partfootdtlseg);

		return partfootdtlseg;
	}

	private PARTFOOTDTLSEG buildXMLPartFootDtlNivel1(final ProntoFormProductoMedida registro, ObjectFactory factory) {
		PARTFOOTDTLSEG partfootdtlseg;
		// @formatter:off
		partfootdtlseg = buildXMLPartFootDtl(
				registro.getUnidadCodigo2(), 
				registro.getFactorConversion2(),
				registro.getLargo2(),
				registro.getAncho2(),
				registro.getAlto2(),
				registro.getPeso2(),
				factory);
		// @formatter:on

		fillValoresNivel1(partfootdtlseg);

		return partfootdtlseg;
	}

	private PARTFOOTDTLSEG buildXMLPartFootDtlNivel2(final ProntoFormProductoMedida registro, ObjectFactory factory) {
		PARTFOOTDTLSEG partfootdtlseg;
		// @formatter:off
		partfootdtlseg = buildXMLPartFootDtl(
				registro.getUnidadCodigo3(), 
				registro.getFactorConversion3(),
				registro.getLargo3(),
				registro.getAncho3(),
				registro.getAlto3(),
				registro.getPeso3(),
				factory);
		// @formatter:on

		fillValoresNivel2(partfootdtlseg);

		return partfootdtlseg;
	}

	private PARTFOOTDTLSEG buildXMLPartFootDtl(String unidadCodigo, int factorConversion, BigDecimal largo,
			BigDecimal ancho, BigDecimal alto, BigDecimal peso, ObjectFactory factory) {
		PARTFOOTDTLSEG partfootdtlseg = null;
		if (StringUtils.isNotEmpty(unidadCodigo)) {
			partfootdtlseg = factory.createPARTFOOTDTLSEG();

			fillValoresRegistro(partfootdtlseg, unidadCodigo, factorConversion, largo, ancho, alto, peso);
			fillValoresConstantes(partfootdtlseg);
		}
		return partfootdtlseg;
	}

	private void fillValoresRegistro(PARTFOOTDTLSEG partfootdtlseg, String unidadCodigo, int factorConversion,
			BigDecimal largo, BigDecimal ancho, BigDecimal alto, BigDecimal peso) {

		if (partfootdtlseg != null) {
			String unt = String.valueOf(factorConversion);
			String len = getDecimalFormat().format(largo);
			String wid = getDecimalFormat().format(ancho);
			String hgt = getDecimalFormat().format(alto);
			String wgt = getDecimalFormat().format(peso);

			partfootdtlseg.setUOMCOD(unidadCodigo);
			partfootdtlseg.setUNTQTY(unt);
			partfootdtlseg.setLEN(len);
			partfootdtlseg.setWID(wid);
			partfootdtlseg.setHGT(hgt);
			partfootdtlseg.setGRSWGT(wgt);
			partfootdtlseg.setNETWGT(wgt);
		}

	}

	private void fillValoresConstantes(PARTFOOTDTLSEG partfootdtlseg) {
		if (partfootdtlseg != null) {
			partfootdtlseg.setSEGNAM("PARTFOOT_DTL");
			partfootdtlseg.setTHRESHPCT("100");
			partfootdtlseg.setBULKPCKFLG("0");
		}
	}

	private void fillValoresNivel0(PARTFOOTDTLSEG partfootdtlseg) {
		if (partfootdtlseg != null) {
			partfootdtlseg.setUOMLVL("0");
			partfootdtlseg.setPALFLG("0");
			partfootdtlseg.setCASFLG("0");
			partfootdtlseg.setPAKFLG("0");
			partfootdtlseg.setSTKFLG("1");
			partfootdtlseg.setRCVFLG("1");
		}
	}

	private void fillValoresNivel1(PARTFOOTDTLSEG partfootdtlseg) {
		if (partfootdtlseg != null) {
			partfootdtlseg.setUOMLVL("1");
			partfootdtlseg.setPALFLG("0");
			partfootdtlseg.setCASFLG("1");
			partfootdtlseg.setPAKFLG("0");
			partfootdtlseg.setSTKFLG("0");
			partfootdtlseg.setRCVFLG("0");
		}
	}

	private void fillValoresNivel2(PARTFOOTDTLSEG partfootdtlseg) {
		if (partfootdtlseg != null) {
			partfootdtlseg.setUOMLVL("2");
			partfootdtlseg.setPALFLG("1");
			partfootdtlseg.setCASFLG("0");
			partfootdtlseg.setPAKFLG("0");
			partfootdtlseg.setSTKFLG("0");
			partfootdtlseg.setRCVFLG("0");
		}
	}

	private static DecimalFormat decimalFormat = null;

	public DecimalFormat getDecimalFormat() {
		if (decimalFormat == null) {
			DecimalFormatSymbols symbols = new DecimalFormatSymbols();
			symbols.setDecimalSeparator(SEPARADOR_DECIMAL);
			symbols.setGroupingSeparator(SEPARADOR_GRUPO);

			decimalFormat = new DecimalFormat(FORMATO_DECIMAL, symbols);
			decimalFormat.setParseBigDecimal(true);
		}
		return decimalFormat;
	}
}
