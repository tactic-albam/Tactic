package com.tacticlogistics.integrador.db.handlers;

import java.io.Serializable;

import com.tacticlogistics.integrador.model.etl.Archivo;
import com.tacticlogistics.integrador.model.etl.TipoArchivo;

import lombok.Data;
import lombok.ToString;

@ToString
@Data
public class DbRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private TipoArchivo tipoArchivo;
	
	private Archivo archivo;

}