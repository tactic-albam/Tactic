package com.tacticlogistics.integrador.db.handlers;

import com.tacticlogistics.core.patterns.AbstractHandler;

public abstract class DbHandler extends AbstractHandler<DbRequest> {


}
