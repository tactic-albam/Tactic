package com.tacticlogistics.integrador.files.clientes.heinz.maestros.precios;

import java.util.Optional;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.Assert;

import com.tacticlogistics.integrador.files.decorators.Decorator;
import com.tacticlogistics.integrador.files.decorators.Filter;
import com.tacticlogistics.integrador.files.dto.ArchivoDTO;
import com.tacticlogistics.integrador.files.dto.RegistroDTO;
import com.tacticlogistics.integrador.model.clientes.heinz.precios.ProductoPrecio;
import com.tacticlogistics.integrador.model.etl.Campo;

import lombok.val;

public class EnriquecerCamposDecorator extends Decorator<ProductoPrecio> {

	public EnriquecerCamposDecorator() {
		super();
	}

	public EnriquecerCamposDecorator(Filter<ProductoPrecio> inner) {
		super(inner);
	}

	@Override
	public ArchivoDTO<ProductoPrecio> transformar(ArchivoDTO<ProductoPrecio> archivoDTO) {
		final val result = super.transformar(archivoDTO);
		val registros = result.getRegistros();
		Assert.notEmpty(registros);

		val tipoArchivo = result.getTipoArchivo();
		Assert.notNull(tipoArchivo);

		val path = result.getPathArchivo();
		Assert.notNull(path);

		val nombreArchivo = path.getFileName().toString().toUpperCase();
		val terceroCodigo = FilenameUtils.removeExtension(nombreArchivo);

		// @formatter:off
		val configuracion = tipoArchivo
				.getConfiguraciones()
				.stream()
				.filter(a -> a.getCodigo().equals(terceroCodigo))
				.findFirst();
		// @formatter:on
		Assert.isTrue(configuracion.isPresent());

		val campoProductoCodigo = tipoArchivo.getCampoPorCodigo(ProductoPrecio.PRODUCTO_CODIGO);
		Assert.isTrue(campoProductoCodigo.isPresent());

		val campoValorUnitario = tipoArchivo.getCampoPorCodigo(ProductoPrecio.VALOR_UNITARIO);
		Assert.isTrue(campoValorUnitario.isPresent());

		val campoRedondeo = tipoArchivo.getCampoPorCodigo(ProductoPrecio.REDONDEO);
		Assert.isTrue(campoRedondeo.isPresent());

		val terceroIdentificacion = configuracion.get().getValor();

		for (val registro : registros) {
			registro.getDatos().put(ProductoPrecio.TERCERO_IDENTIFICACION, terceroIdentificacion);
			cambiarValorUnitario(registro, campoValorUnitario);
			cambiarValoresNoDecimales(registro, campoProductoCodigo);
			cambiarValoresNoDecimales(registro, campoRedondeo);
		}

		return result;
	}

	private void cambiarValorUnitario(final RegistroDTO<ProductoPrecio> registro, final Optional<Campo> campo) {
		String valor = registro.getDatos().get(ProductoPrecio.VALOR_UNITARIO);
		valor = StringUtils.left(valor, campo.get().getNumeroCaracteres());
		registro.getDatos().put(ProductoPrecio.VALOR_UNITARIO, valor);
	}

	private void cambiarValoresNoDecimales(final RegistroDTO<ProductoPrecio> registro, final Optional<Campo> campo) {
		String campoCodigo = campo.get().getCodigo();
		String valor = registro.getDatos().get(campoCodigo);
		valor = StringUtils.replace(valor, ",", ".");
		val index = StringUtils.indexOf(valor, ".");
		if (index > 0) {
			valor = StringUtils.left(valor, index);
			registro.getDatos().put(campoCodigo, valor);
		}
	}
}
