package com.tacticlogistics.integrador.files.clientes.tactic.tms.rutas.rutacontrol;

import org.springframework.util.Assert;

import com.tacticlogistics.integrador.files.decorators.Decorator;
import com.tacticlogistics.integrador.files.decorators.Filter;
import com.tacticlogistics.integrador.files.dto.ArchivoDTO;
import com.tacticlogistics.integrador.model.clientes.tactic.tms.rutas.rutacontrol.VisitaRutaControl;

import lombok.val;

public class FiltrarVisitaRutaControlDecorator extends Decorator<VisitaRutaControl> {

	public FiltrarVisitaRutaControlDecorator() {
		super();
	}

	public FiltrarVisitaRutaControlDecorator(Filter<VisitaRutaControl> inner) {
		super(inner);
	}

	@Override
	public ArchivoDTO<VisitaRutaControl> transformar(ArchivoDTO<VisitaRutaControl> archivoDTO) {
		final val result = super.transformar(archivoDTO);
		Assert.notNull(result.getTipoArchivo());
		Assert.notNull(result.getDatos());

		String separador = result.getTipoArchivo().getRegExpSeparadorRegistros();
		String[] lineas = result.getDatos().split(separador, -1);

		StringBuilder sb = new StringBuilder();
		separador = result.getTipoArchivo().getUnescapedSeparadorRegistros();

		for (String linea : lineas) {
			if(linea.isEmpty()){
				continue;
			}

			sb.append(linea).append(separador);
		}

		result.setDatos(sb.toString());

		return result;
	}
}
