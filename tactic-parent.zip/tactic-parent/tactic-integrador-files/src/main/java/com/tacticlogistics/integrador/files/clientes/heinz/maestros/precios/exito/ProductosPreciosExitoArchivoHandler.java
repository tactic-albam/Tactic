
package com.tacticlogistics.integrador.files.clientes.heinz.maestros.precios.exito;

import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.tacticlogistics.integrador.files.clientes.heinz.maestros.precios.ProductoPrecioArchivoHandler;

@Component
public class ProductosPreciosExitoArchivoHandler extends ProductoPrecioArchivoHandler {
	protected static final Pattern PATTERN = Pattern.compile("(?i:EXITO\\.(xlsx|xls))");

	@Override
	protected Pattern getFileNamePattern() {
		return PATTERN;
	}
}
