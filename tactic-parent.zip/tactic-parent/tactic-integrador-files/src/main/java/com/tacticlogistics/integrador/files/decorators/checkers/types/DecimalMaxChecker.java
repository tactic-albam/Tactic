package com.tacticlogistics.integrador.files.decorators.checkers.types;

import java.math.BigDecimal;

import com.tacticlogistics.integrador.model.etl.Campo;

public class DecimalMaxChecker extends MaxChecker<BigDecimal> {
	@Override
	protected BigDecimal getValorLimite(Campo campo) {
		return campo.getValorDecimalMax();
	}
}
