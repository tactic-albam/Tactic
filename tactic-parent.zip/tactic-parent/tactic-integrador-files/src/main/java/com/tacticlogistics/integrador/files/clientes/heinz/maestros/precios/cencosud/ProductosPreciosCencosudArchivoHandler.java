
package com.tacticlogistics.integrador.files.clientes.heinz.maestros.precios.cencosud;

import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.tacticlogistics.integrador.files.clientes.heinz.maestros.precios.ProductoPrecioArchivoHandler;

@Component
public class ProductosPreciosCencosudArchivoHandler extends ProductoPrecioArchivoHandler {
	protected static final Pattern PATTERN = Pattern.compile("(?i:CENCOSUD\\.(xlsx|xls))");

	@Override
	protected Pattern getFileNamePattern() {
		return PATTERN;
	}
}
