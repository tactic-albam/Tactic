package com.tacticlogistics.integrador.files.clientes.gws.salidas;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.tacticlogistics.ClienteCodigoType;
import com.tacticlogistics.integrador.files.clientes.tactic.oms.MapEntidadSalidaDecorator;
import com.tacticlogistics.integrador.files.decorators.CamposSplitterDecorator;
import com.tacticlogistics.integrador.files.decorators.CheckArchivoVacioDecorator;
import com.tacticlogistics.integrador.files.decorators.CheckNumeroDeColumnasDecorator;
import com.tacticlogistics.integrador.files.decorators.CheckRegistrosDuplicadosDecorator;
import com.tacticlogistics.integrador.files.decorators.CheckRestriccionesDeCamposDecorator;
import com.tacticlogistics.integrador.files.decorators.Decorator;
import com.tacticlogistics.integrador.files.decorators.IncluirCamposDecorator;
import com.tacticlogistics.integrador.files.decorators.IncluirEncabezadoDecorator;
import com.tacticlogistics.integrador.files.decorators.LineasSplitterDecorator;
import com.tacticlogistics.integrador.files.decorators.MayusculasDecorator;
import com.tacticlogistics.integrador.files.decorators.NormalizarSeparadoresDeRegistroDecorator;
import com.tacticlogistics.integrador.files.handlers.ArchivoHandler;
import com.tacticlogistics.integrador.files.readers.CharsetDetectorFileReaderBeta;
import com.tacticlogistics.integrador.files.readers.Reader;
import com.tacticlogistics.integrador.model.oms.Salida;
import com.tacticlogistics.integrador.model.oms.SalidaRepository;

@Component
public class GwsSalidasArchivoHandler extends ArchivoHandler<Salida,Long> {
	private static final String CODIGO_TIPO_ARCHIVO = "GWS_SALIDAS";

	@Autowired
	private CharsetDetectorFileReaderBeta reader;

	@Autowired
	private SalidaRepository repository;

	// ----------------------------------------------------------------------------------------------------------------
	//
	// ----------------------------------------------------------------------------------------------------------------
	@Override
	protected Reader getReader() {
		return reader;
	}

	@Override
	protected String getCodigoTipoArchivo() {
		return CODIGO_TIPO_ARCHIVO;
	}

	@Override
	protected Path getCliente() {
		Path result = Paths.get(ClienteCodigoType.GWS.toString());
		return result;
	}

	@Override
	protected Path getSubDirectorioRelativo() {
		Path result = Paths.get("ORDENES\\VENTAS");
		return result;
	}

	@Override
	protected Pattern getFileNamePattern() {
		return PATTERN_TXT;
	}
	
	@Override
	protected Decorator<Salida> getTransformador() {
		// @formatter:off
		return new MapEntidadSalidaDecorator(
				new CheckRegistrosDuplicadosDecorator<Salida>(
					new CheckRestriccionesDeCamposDecorator<Salida>(
						new EnriquecerCamposDecorator(
							new IncluirCamposDecorator<Salida>(
								new CamposSplitterDecorator<Salida>(
									new CheckNumeroDeColumnasDecorator<Salida>(
										new CheckArchivoVacioDecorator<Salida>(
											new LineasSplitterDecorator<Salida>(
												new IncluirEncabezadoDecorator<Salida>(
													new NormalizarSeparadoresDeRegistroDecorator<Salida>(
														new MayusculasDecorator<Salida>(
				))))))))))));
		// @formatter:on
	}

	@Override
	protected JpaRepository<Salida, Long> getRepository() {
		return repository;
	}
}
