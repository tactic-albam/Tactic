package com.tacticlogistics.integrador.files.decorators;

import com.tacticlogistics.integrador.files.dto.ArchivoDTO;

public interface Filter<T> {
	ArchivoDTO<T> transformar(ArchivoDTO<T> archivoDTO);
}
