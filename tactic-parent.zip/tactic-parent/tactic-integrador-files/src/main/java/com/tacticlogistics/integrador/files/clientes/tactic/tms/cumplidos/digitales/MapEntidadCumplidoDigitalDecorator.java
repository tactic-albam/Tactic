package com.tacticlogistics.integrador.files.clientes.tactic.tms.cumplidos.digitales;

import org.springframework.util.Assert;

import com.tacticlogistics.integrador.files.decorators.Filter;
import com.tacticlogistics.integrador.files.decorators.MapEntidadDecorator;
import com.tacticlogistics.integrador.files.dto.ArchivoDTO;
import com.tacticlogistics.integrador.files.dto.RegistroDTO;
import com.tacticlogistics.integrador.model.clientes.tactic.tms.cumplidos.CumplidoDigital;
import com.tacticlogistics.integrador.model.etl.EstadoEtlType;

import lombok.val;

public class MapEntidadCumplidoDigitalDecorator extends MapEntidadDecorator<CumplidoDigital> {

	public MapEntidadCumplidoDigitalDecorator() {
		super();
	}

	public MapEntidadCumplidoDigitalDecorator(Filter<CumplidoDigital> inner) {
		super(inner);
	}

	@Override
	protected CumplidoDigital map(ArchivoDTO<CumplidoDigital> archivoDTO, RegistroDTO<CumplidoDigital> registro) {
		val tipoArchivo = archivoDTO.getTipoArchivo();
		Assert.notNull(tipoArchivo);
		val archivo = archivoDTO.getArchivo();
		Assert.notNull(archivo);
		val datos = registro.getDatos();
		Assert.notEmpty(datos);

		// @formatter:off
		val result = CumplidoDigital.builder()
				.idArchivo(archivo.getId())
				.estadoRegistro(EstadoEtlType.ESTRUCTURA_VALIDADA)
				.linea(registro.getLinea())
				.fechaCreacion(archivo.getFechaCreacion())
				.usuarioCreacion(archivo.getUsuarioCreacion())
				.fechaActualizacion(archivo.getFechaCreacion())
				.usuarioActualizacion(archivo.getUsuarioCreacion())

				.nombreArchivo(datos.get(CumplidoDigital.NOMBRE_ARCHIVO))
				.clienteNombre(datos.get(CumplidoDigital.CLIENTE_NOMBRE))
				.numeroOrden(datos.get(CumplidoDigital.NUMERO_ORDEN))
				.build();
		// @formatter:on

		return result;
	}
}
