package com.tacticlogistics.integrador.files.clientes.tactic.tms.cumplidos.digitales;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.tacticlogistics.ClienteCodigoType;
import com.tacticlogistics.integrador.files.decorators.CamposSplitterDecorator;
import com.tacticlogistics.integrador.files.decorators.CheckArchivoVacioDecorator;
import com.tacticlogistics.integrador.files.decorators.CheckNumeroDeColumnasDecorator;
import com.tacticlogistics.integrador.files.decorators.CheckRegistrosDuplicadosDecorator;
import com.tacticlogistics.integrador.files.decorators.CheckRestriccionesDeCamposDecorator;
import com.tacticlogistics.integrador.files.decorators.Decorator;
import com.tacticlogistics.integrador.files.decorators.IncluirEncabezadoDecorator;
import com.tacticlogistics.integrador.files.decorators.LineasSplitterDecorator;
import com.tacticlogistics.integrador.files.decorators.MayusculasDecorator;
import com.tacticlogistics.integrador.files.decorators.NormalizarSeparadoresDeRegistroDecorator;
import com.tacticlogistics.integrador.files.handlers.ArchivoHandler;
import com.tacticlogistics.integrador.files.readers.CharsetDetectorFileReaderBeta;
import com.tacticlogistics.integrador.files.readers.Reader;
import com.tacticlogistics.integrador.model.clientes.tactic.tms.cumplidos.CumplidoDigital;
import com.tacticlogistics.integrador.model.clientes.tactic.tms.cumplidos.CumplidoDigitalRepository;

@Component
public class CumplidosDigitalesArchivoHandler extends ArchivoHandler<CumplidoDigital, Long> {
	private static final String CODIGO_TIPO_ARCHIVO = "CUMPLIDOS_DIGITALES";

	@Autowired
	private CharsetDetectorFileReaderBeta reader;

	@Autowired
	private CumplidoDigitalRepository repository;

	// ----------------------------------------------------------------------------------------------------------------
	//
	// ----------------------------------------------------------------------------------------------------------------
	@Override
	protected Reader getReader() {
		return reader;
	}

	@Override
	protected String getCodigoTipoArchivo() {
		return CODIGO_TIPO_ARCHIVO;
	}

	@Override
	protected Path getCliente() {
		Path result = Paths.get(ClienteCodigoType.TACTIC.toString());
		return result;
	}

	@Override
	protected Path getSubDirectorioRelativo() {
		Path result = Paths.get("TMS\\CUMPLIDOS\\DIGITALES");
		return result;
	}

	@Override
	protected Pattern getFileNamePattern() {
		return PATTERN_TXT;
	}

	@Override
	protected Decorator<CumplidoDigital> getTransformador() {
		// @formatter:off
		return new MapEntidadCumplidoDigitalDecorator(
				new CheckRegistrosDuplicadosDecorator<CumplidoDigital>(
					new CheckRestriccionesDeCamposDecorator<CumplidoDigital>(
						new ExtraerCamposCumplidoDigitalDecorator(
							new FiltrarCumplidoDigitalDecorator(
								new CamposSplitterDecorator<CumplidoDigital>(
									new CheckNumeroDeColumnasDecorator<CumplidoDigital>(
										new CheckArchivoVacioDecorator<CumplidoDigital>(
											new LineasSplitterDecorator<CumplidoDigital>(
												new IncluirEncabezadoDecorator<CumplidoDigital>(
													new NormalizarSeparadoresDeRegistroDecorator<CumplidoDigital>(
														new MayusculasDecorator<CumplidoDigital>())))))))))));
		// @formatter:on
	}

	@Override
	protected JpaRepository<CumplidoDigital, Long> getRepository() {
		return repository;
	}
}