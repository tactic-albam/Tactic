package com.tacticlogistics.integrador.model.clientes.tactic.tms.cumplidos;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CumplidoDigitalRepository extends JpaRepository<CumplidoDigital, Long> {

}
