package com.tacticlogistics.integrador.model.clientes.tactic.tms.rutas.manuales;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RutaManualRepository extends JpaRepository<RutaManual, Long> {

}
