package com.tacticlogistics.integrador.model.clientes.heinz.precios;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoPrecioRepository extends JpaRepository<ProductoPrecio, Long> {

}
