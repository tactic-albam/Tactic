package com.tacticlogistics.integrador.model.oms;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ReciboRepository extends JpaRepository<Recibo, Long> {

}
