package com.tacticlogistics.integrador.model.clientes.tactic.tms.rutas.rutacontrol;

import org.springframework.data.jpa.repository.JpaRepository;

public interface VisitaRutaControlRepository extends JpaRepository<VisitaRutaControl, Long> {

}
