package com.tacticlogistics.integrador.model.clientes.tactic.tms.rutas.toursolver;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RutaTourSolverRepository extends JpaRepository<RutaTourSolver, Long> {

}
