package com.tacticlogistics.integrador.model.etl;

public enum TipoDatoType {
	STRING,
	INTEGER,
	DECIMAL,
	DATETIME,
	DATE,
	TIME
}
