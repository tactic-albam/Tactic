package com.tacticlogistics.integrador.model.etl;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ArchivoRepository extends JpaRepository<Archivo, Long> {
	List<Archivo> findByEstadoArchivo(EstadoEtlType estadoArchivo);
}
