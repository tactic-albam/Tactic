package com.tacticlogistics.integrador.model.oms;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SalidaRepository extends JpaRepository<Salida, Long> {

}
