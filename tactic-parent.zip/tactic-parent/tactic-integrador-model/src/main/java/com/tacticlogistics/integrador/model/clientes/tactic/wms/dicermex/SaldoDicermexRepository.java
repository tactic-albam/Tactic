package com.tacticlogistics.integrador.model.clientes.tactic.wms.dicermex;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SaldoDicermexRepository extends JpaRepository<SaldoDicermex, Long> {

}
