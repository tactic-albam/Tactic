package com.tacticlogistics.integrador.model.clientes.tactic.tms.rutas.moviles;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MovilRutaControlRepository extends JpaRepository<MovilRutaControl, Long> {

}
