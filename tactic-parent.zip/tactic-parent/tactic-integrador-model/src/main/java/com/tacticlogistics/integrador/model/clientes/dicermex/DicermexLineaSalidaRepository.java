package com.tacticlogistics.integrador.model.clientes.dicermex;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DicermexLineaSalidaRepository extends JpaRepository<DicermexLineaSalida, Long> {

}
