package com.tacticlogistics.integrador.model.etl;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CampoRepository extends JpaRepository<Campo, Long> {

}
