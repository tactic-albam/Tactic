package com.tacticlogistics;

public enum ClienteCodigoType {
	DICERMEX,
	GWS,
	HEINZ,
	PANECO,
	TACTIC
}
