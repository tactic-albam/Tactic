package com.tacticlogistics.integrador.ftp.services;

public interface CheckDirectoriosService {
	void check();
}