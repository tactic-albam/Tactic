package com.tacticlogistics.integrador.mail.etl.handlers;

import com.tacticlogistics.core.patterns.AbstractHandler;
import com.tacticlogistics.integrador.mail.fetch.dto.MailMessage;

public abstract class MailMessageHandler extends AbstractHandler<MailMessage> {

}
