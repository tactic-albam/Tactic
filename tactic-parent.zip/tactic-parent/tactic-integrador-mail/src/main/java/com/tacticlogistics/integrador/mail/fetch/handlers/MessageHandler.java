package com.tacticlogistics.integrador.mail.fetch.handlers;

import com.tacticlogistics.core.patterns.AbstractHandler;

public class MessageHandler extends AbstractHandler<MessageRequest> {

	@Override
	protected boolean canHandleRequest(MessageRequest request) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	protected void handleRequest(MessageRequest request) {
		// TODO Auto-generated method stub
		
	}

}
